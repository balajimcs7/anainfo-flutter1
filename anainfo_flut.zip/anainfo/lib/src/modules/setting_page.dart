import 'package:anainfo/src/widget/nav_drawer.dart';
import 'package:flutter/material.dart';

class SettingPage extends StatefulWidget {

  static const String routeName = '/settingPage';
  @override
  State<StatefulWidget> createState() {
    return _SettingPage();
  }
}

class _SettingPage extends State<SettingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Setting"),
      ),
      drawer: NavDrawer(),
    );
  }
}
