import 'package:anainfo/src/utils/shared_pref.dart';
import 'package:flutter/material.dart';

import '../widget/nav_drawer.dart';
import '../screens/login_screen.dart';

class HomePage extends StatefulWidget {
  static const String routeName = '/homePage';
  @override
  State<StatefulWidget> createState() {
    return _HomePage();
  }
}

class _HomePage extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: const Center(
        child: Text("Home page"),
      ),
      drawer: NavDrawer(),
    );
  }
}

void showAlertDialog(BuildContext context, String content) {
  Widget okBtn = TextButton(
      onPressed: () {
        SharedPref.instance.removeAll();
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => LoginScreen()));
      },
      child: Text("Ok"));
  Widget cancelBtn = TextButton(
      onPressed: () {
        Navigator.of(context, rootNavigator: true).pop();
      },
      child: Text("Cancel"));

  var alertDialog = AlertDialog(
    title: Text("Alert"),
    content: Text(content),
    actions: [
      okBtn,
      cancelBtn,
    ],
  );
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return alertDialog;
      });
}
