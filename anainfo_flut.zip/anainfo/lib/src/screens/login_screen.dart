import 'package:anainfo/src/api/api.dart';
import 'package:anainfo/src/screens/new_login.dart';
import 'package:anainfo/src/utils/shared_pref.dart';
import 'package:flutter/material.dart';

import '../modules/home_page.dart';

class LoginScreen extends StatefulWidget {
  static const String routeName = '/loginPage';

  @override
  State<StatefulWidget> createState() {
    return _LoginScreen();
  }
}

class _LoginScreen extends State<LoginScreen> {
  final _minimumPadding = 5.0;
  TextEditingController mailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  var _formKey = GlobalKey<FormState>();

  _login() async {
    var loginData = {
      'email': mailController.text,
      'password': passwordController.text
    };
    var res = await Api().postLogin(loginData, 'loginuser');
    print("loginresponse$res");
    final status = res["status"];
    print("loginresponse$status");

    if (status == "success") {
      SharedPref.instance.setBooleanValue("loggedin", true);

      Navigator.pushAndRemoveUntil(
          context,
          new MaterialPageRoute(builder: (context) => HomePage()),
          (Route<dynamic> route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Padding(
            padding: EdgeInsets.all(_minimumPadding),
            child: ListView(
              children: <Widget>[
                getImage(),
                Padding(
                    padding: EdgeInsets.only(
                        top: _minimumPadding, bottom: _minimumPadding),
                    child: TextFormField(
                      validator: (String? value) {
                        if (value!.isEmpty) {
                          return "Enter the mail";
                        }
                        return null;
                      },
                      controller: mailController,
                      decoration: InputDecoration(
                          labelText: "Mail",
                          hintText: "Enter the mail",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0))),
                    )),
                Padding(
                    padding: EdgeInsets.only(
                        top: _minimumPadding, bottom: _minimumPadding),
                    child: TextFormField(
                      validator: (String? value) {
                        if (value!.isEmpty) {
                          return "Enter the Password";
                        }
                        return null;
                      },
                      controller: passwordController,
                      decoration: InputDecoration(
                          labelText: "Password",
                          hintText: "Enter the password",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0))),
                    )),
                Padding(
                  padding: EdgeInsets.all(_minimumPadding),
                  child: Row(
                    children: [
                      Expanded(
                          child: ElevatedButton(
                        child: Text("Login"),
                        onPressed: () {
                          setState(() {
                            if (_formKey.currentState!.validate()) {
                              _login();
                            }
                          });
                        },
                      )),
                      Expanded(
                          child: ElevatedButton(
                        child: Text("newLogin"),
                        onPressed: () {
                          setState(() {
                            Navigator.pushAndRemoveUntil(
                                context,
                                new MaterialPageRoute(builder: (context) => NewLogin()),
                                    (Route<dynamic> route) => false);
                          });
                        },
                      ))
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }

  Widget getImage() {
    AssetImage assetImage = AssetImage("assets/images/app_logo.png");
    Image image = Image(
      image: assetImage,
      width: 150.0,
      height: 150.0,
    );
    return Container(
      child: image,
      margin: EdgeInsets.all(20.0),
    );
  }
}

void showAlertDialog(BuildContext context, String content) {
  Widget okBtn = TextButton(
      onPressed: () {
        Navigator.of(context, rootNavigator: true).pop();
      },
      child: Text("Ok"));

  var alertDialog = AlertDialog(
    title: Text("Alert"),
    content: Text(content),
    actions: [
      okBtn,
    ],
  );
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return alertDialog;
      });
}
