import 'package:anainfo/src/routes/page_routes.dart';
import 'package:flutter/material.dart';

import '../screens/login_screen.dart';
import '../utils/shared_pref.dart';

class NavDrawer extends StatefulWidget {
  const NavDrawer({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _NavDrawer();
  }
}

class _NavDrawer extends State<NavDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        // padding: EdgeInsets.all(_padding),
        children: [
          navigationHeader(),
          ListTile(
            leading: Icon(Icons.home_filled),
            title: Text("Home"),
            onTap: () {
              Navigator.pushReplacementNamed(context, PageRoutes.home);
            },
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text("Service"),
            onTap: () {
              Navigator.pushReplacementNamed(context, PageRoutes.setting);
            },
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text("Logout"),
            onTap: () {
              showAlertDialog(context, "Are you sure want to logout");
            },
          )
        ],
      ),
    );
  }
}

Widget navigationHeader() {
  return const UserAccountsDrawerHeader(
    accountName: Text("User name"),
    accountEmail: Text("usermail@gmail.com"),
    decoration: BoxDecoration(color: Colors.blueAccent),
    currentAccountPicture: CircleAvatar(
      backgroundColor: Colors.purple,
      child: Text(
        "U",
        style: TextStyle(
          fontSize: 35.0,
        ),
      ),
    ),
  );
}

void showAlertDialog(BuildContext context, String content) {
  Widget okBtn = TextButton(
      onPressed: () {
        SharedPref.instance.removeAll();
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (BuildContext context) => LoginScreen()),
            (route) => false);
      },
      child: Text("Ok"));
  Widget cancelBtn = TextButton(
      onPressed: () {
        Navigator.of(context, rootNavigator: true).pop();
      },
      child: Text("Cancel"));

  var alertDialog = AlertDialog(
    title: Text("Alert"),
    content: Text(content),
    actions: [
      okBtn,
      cancelBtn,
    ],
  );
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return alertDialog;
      });
}
