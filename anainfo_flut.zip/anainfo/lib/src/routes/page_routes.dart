import 'package:anainfo/src/modules/home_page.dart';
import 'package:anainfo/src/modules/setting_page.dart';
import 'package:anainfo/src/screens/login_screen.dart';
import 'package:anainfo/src/screens/splash_screen.dart';

class PageRoutes{
  static const String splash = SplashScreen.routeName;
  static const String login = LoginScreen.routeName;
  static const String home = HomePage.routeName;
  static const String setting = SettingPage.routeName;
}