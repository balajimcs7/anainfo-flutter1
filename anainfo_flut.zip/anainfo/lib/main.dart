import 'package:anainfo/src/modules/home_page.dart';
import 'package:anainfo/src/modules/setting_page.dart';
import 'package:anainfo/src/routes/page_routes.dart';
import 'package:anainfo/src/screens/login_screen.dart';
import 'package:anainfo/src/screens/splash_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
      routes: {
        PageRoutes.home:(context) => HomePage(),
        PageRoutes.setting:(context) => SettingPage(),
      },
    );
  }
}
